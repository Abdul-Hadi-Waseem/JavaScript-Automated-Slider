var time;
function autoPlay(){
    var counter = 1;
time=setInterval(function(){
    document.getElementById("radio" + counter).checked = true;
    counter++;
    if(counter>4){
        counter = 1;
    }
},3000);
}
try {
    function stopAutoPlay(){
   
        clearInterval(time);
        var counter = 1;
        document.getElementById("radio" + counter).checked = true;
    
    }
    
} catch (error) {
    console.log(error);
}

